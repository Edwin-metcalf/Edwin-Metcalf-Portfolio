public class Main {
    public static void main(String[] args){
            Registrar angela = new Registrar();
            //The algorithm runs in the constructor.

    }
}
